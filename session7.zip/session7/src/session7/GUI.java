/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session7;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import javax.swing.*;
import java.awt.Label;

/**
 *
 * @author Ali
 */
public class GUI {
    
    JFrame jframe;
    
    public GUI(){
        init();
        
    }
         
       public void init(){
        jframe = new JFrame();
        jframe.setSize(300, 500);
        jframe.setLocation(600, 300);
        jframe.setLayout(null);
        jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        draw();
        jframe.setVisible(true);
    }
       
     public void draw(){       
    drawKeyboard();    
      drawScreen();  
    }
   //
     
     
     
     //
      public void drawKeyboard(){
         
          
        JPanel jp = new JPanel();
        jp.setBackground(Color.yellow);
        jp.setLocation(300, 0);
        jp.setSize(600, 200);
        jp.setLayout(new GridLayout(3,5));
        
        
        
        
        JPanel jp2 = new JPanel();
        jp2.setBackground(Color.cyan);
        jp2.setLocation(300, 0);
        jp2.setSize(240, 200);
        jp2.setLayout(new GridLayout(7,5));
                
        for(int i = 0 ; i < 10 ; i++){
            JButton button = new JButton("" + i);
           jp.add(button);
        }
      
        
        JButton t1 = new JButton("+");
        jp.add(t1);
        JButton t2 = new JButton("=");
        jp.add(t2);
        JButton t3 = new JButton("*");
        jp.add(t3);
        JButton t4 = new JButton("/");
        jp.add(t4);
        JButton t5 = new JButton("-");
        jp.add(t5);
        
        
        for(int i = 0 ; i < 10 ; i++){
            JButton button = new JButton("" + i);
           jp2.add(button);
        }

        JButton b1 = new JButton("+");
        jp2.add(b1);
        JButton b2 = new JButton("=");
        jp2.add(b2);
        JButton b3 = new JButton("*");
        jp2.add(b3);
        JButton b4 = new JButton("/");
        jp2.add(b4);
        JButton b5 = new JButton("-");
        jp2.add(b5);
        JButton t6 = new JButton("sin");
        jp2.add(t6);
        JButton t7 = new JButton("cos");
        jp2.add(t7);
        JButton t8 = new JButton("tan");
        jp2.add(t8);
        JButton t9 = new JButton("Shift");
        jp2.add(t9);
        JButton t10 = new JButton("pi");
        jp2.add(t10);
        JButton t11 = new JButton("e");
        jp2.add(t11);
        
        JTabbedPane tap = new JTabbedPane();

        tap.add("normal", jp);
        tap.setSize(500, 150);
        tap.setLocation(500, 300);
        tap.setBounds(500, 500, 200, 200);

        
        tap.add("mohandesi", jp2);
        tap.setSize(400, 520);
        tap.setLocation(500, 300);
        tap.setBounds(5, 185, 275, 270);
        
        
      //   jframe.setSize(400, 400);
        // jframe.setLayout(null);
        // jframe.setVisible(true);
        
        
        
        
        //jframe.add(jp);
        jframe.add(tap);
     }
 
    
    public void drawScreen(){
    
        JTextArea jt = new JTextArea();
        jt.setEditable(false);
        jt.setFont(new Font("Arial", 14 , 14));

           
        JScrollPane js = new JScrollPane(jt);
        js.setSize(265,160);
        js.setLocation(10, 20);
  
        jframe.setTitle("Title");
        
        jframe.add(js);
}
   
}
