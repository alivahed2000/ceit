/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session7;

import javax.swing.*;

/**
 *
 * @author Ali
 */
public class Session7 extends GUI {

    public static void main(String[] args) {
    
    
        try{
            for(UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()){
                if("Nimbus".equals(info.getName())){
                    UIManager.setLookAndFeel(info.getClassName()); 
                    break;
                }
            }
        }catch(Exception ex){
            System.err.println(ex);
        }
        
        GUI test = new GUI();
    }
    
}
   
