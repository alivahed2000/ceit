/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session5;

/**
 *
 * @author Ali
 */
public class Circle extends Shape {
    
    int radius;
    
    Circle(int radius){
        radius = 0;
    }
    
    public int getRadius(){
        return radius;  
    }
}
