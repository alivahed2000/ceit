/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session5;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Ali
 */
public class Paint {
    
    int radius;// it is for circle
    List<Class<Circle>> Clist;    
    List<Class<Triangle>> Tlist;    
    List<Class<Rectangle>> Rlist;
    private Class<Circle> c1;
    private Class<Triangle> t1;
    private Class<Rectangle> r1;

    public Paint() {
        this.Clist = new ArrayList<Class<Circle>>();
        this.Tlist = new ArrayList<Class<Triangle>>();
        this.Rlist = new ArrayList<Class<Rectangle>>();
    }
    public void addshape(Circle c,Triangle t,Rectangle r){
        c.Clist.add(c1);
        t.Tlist.add(t1);
        r.Rlist.add(r1);
    }
 public void printAll(){
     Clist.forEach((n) -> System.out.println(n));
     Tlist.forEach((n) -> System.out.println(n));
     Rlist.forEach((n) -> System.out.println(n));
 }
}
