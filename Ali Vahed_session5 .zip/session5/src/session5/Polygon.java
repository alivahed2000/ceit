/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session5;

import java.util.ArrayList;

/**
 *
 * @author Ali
 */
public class Polygon extends Shape {
    
     ArrayList sidesoftri = new ArrayList();//tri
    ArrayList sidesofrect = new ArrayList();//rect
    
  public void detailoftriangle(int st1,int st2,int st3){
      
      sidesoftri.add(st1);
      sidesoftri.add(st2);
      sidesoftri.add(st3);
  }
  
  public void detailofrectangle(int sr1,int sr2,int sr3,int sr4){
      
      sidesofrect.add(sr1);
      sidesofrect.add(sr2);
      sidesofrect.add(sr3);
      sidesofrect.add(sr4);
      // sr1 = sr3      for rectangle
   // sr2 =sr4
  }

}
