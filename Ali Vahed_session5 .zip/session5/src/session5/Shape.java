/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session5;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Ali
 */
public class Shape extends Paint{
    
    
      public void calculatePerimeter(int radius,int st1,int st2,int st3,int sr1,int sr2,int sr3,int sr4){
        double circleperimeter;
        circleperimeter = 2*3.14*radius;
        System.out.printf("%f",circleperimeter);
       
        double triangleperimeter;
        triangleperimeter = st1+st2+st3;
        System.out.printf("%f",triangleperimeter);
        
         double rectangleperimeter;
         rectangleperimeter = 2*(sr1+sr2);
         System.out.printf("%f",rectangleperimeter);
    }
      
      public void calculateArea(int radius,int st1,int st2,int st3,int h,int sr1,int sr2,int sr3,int sr4){
          double circleArea;
          circleArea = 3.14*radius*radius;
          System.out.printf("%f",circleArea);
          
          double triangleArea;  // st1 baraye ghaedeye mosalas hast.
          triangleArea = (st1*h)/2;
          System.out.printf("%f",triangleArea);
          
          double rectangleArea;
          rectangleArea = sr1*sr2;
          System.out.printf("%f",rectangleArea);
      }
      
      public boolean equals(Circle c,Triangle t,Rectangle r){
          if(c.equals(t) || c.equals(r) || r.equals(t)){
              return false;
          }
          else{
              return true;
          }
      }
      
      public String toString(int st1,int st2,int st3,int sr1,int sr2,int sr3,int sr4){
          
      String stringst1 = Integer.toString(st1);
      String stringst2 = Integer.toString(st2);
      String stringst3 = Integer.toString(st3);
      
      System.out.print("stringst1 = " + stringst1);
      System.out.print("stringst2 = " + stringst2);
      System.out.println("stringst3 = " + stringst3);
      
      String stringsr1 = Integer.toString(sr1);
      String stringsr2 = Integer.toString(sr2);
      String stringsr3 = Integer.toString(sr3);
      String stringsr4 = Integer.toString(sr4);
      
      System.out.print("stringsr1 = " + stringsr1);
      System.out.print("stringsr2 = " + stringsr2);
      System.out.print("stringsr3 = " + stringsr3);
      System.out.println("stringsr4 = " + stringsr4);
      
      return null;
      }

}
