/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session5;

/**
 *
 * @author Ali
 */
public class Rectangle extends Polygon{
    
    public void isSquare(int sr1,int sr2,int sr3,int sr4){
        if(sr1 == sr2 && sr3 == sr4){
            System.out.println("It is Square");
        }
    }
}
