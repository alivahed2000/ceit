/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session5;


/**
 *
 * @author Ali
 */
public class Triangle extends Polygon {
    
    public void isEquilateral(int st1, int st2, int st3) {
         
    if(st1 == st2 && st1 == st3 && st2 == st3){
        System.out.println("It is Equilateral");
    }
}
}
