


public class GameBoard {
	private int[][] board;
	
        private void blankBoard()
	{
		for(int i = 0; i < board.length; i++)
		{
			for(int j = 0; j < board[i].length; j++)
				board[i][j] = 0;
		}
	}
	
        
	public GameBoard()
	{
		board = new int[6][6];
		blankBoard();
	}
	
	//used for copying game board moves
	public GameBoard(int[][] moves)
	{
		board = new int[6][6];
		for(int i = 0; i < 6; i++)
		{
			for(int j = 0; j < 6; j++)
				board[i][j] = moves[i][j];
		}
	}
	
        
	public void makeMove(int player, int row, int col)
	{
		//use -1 since input is from 1-6, not 0-5
		board[row - 1][col - 1] = player;
	}
	
	public boolean isValidMove(int row, int col)
	{
		return (board[row - 1][col - 1] == 0);
	}


		public void printBoard()
	{
		for(int i = 0; i < board.length; i++)
		{
			String line = "";
			for(int j = 0; j < board[i].length; j++)
			{
                            switch (board[i][j]) {
                                case 1:
                                    line += "W ";
                                    break;
                                case 2:
                                    line += "B ";
                                    break;
                                default:
                                    line += "0 ";
                                    break;
                            }
				if(j == 2)	//adds vertical middle split to board
					line += "| ";
			}
			System.out.println(line);
			if(i == 2)	//adds horizontal middle split to board
				System.out.println("-------------");
		}
	}
	
		
	//returning 0 = no winner
	//returning 1 = first player (white) wins
	//returning 2 = second player (black) wins
	public int determineWinner()
	{
		
		for(int i = 0; i < 6; i++)
		{
			if(board[i][0] == 1 && board[i][1] == 1 && board[i][2] == 1 && board[i][3] == 1 && board[i][4] == 1)
				return 1;
			if(board[i][0] == 2 && board[i][1] == 2 && board[i][2] == 2 && board[i][3] == 2 && board[i][4] == 2)
				return 2;
		}
		
		
		for(int i = 0; i < 6; i++)
		{
			if(board[i][1] == 1 && board[i][2] == 1 && board[i][3] == 1 && board[i][4] == 1 && board[i][5] == 1)
				return 1;
			if(board[i][1] == 2 && board[i][2] == 2 && board[i][3] == 2 && board[i][4] == 2 && board[i][5] == 2)
				return 2;
		}
		
		
		for(int i = 0; i < 6; i++)
		{
			if(board[0][i] == 1 && board[1][i] == 1 && board[2][i] == 1 && board[3][i] == 1 && board[4][i] == 1)
				return 1;
			if(board[0][i] == 2 && board[1][i] == 2 && board[2][i] == 2 && board[3][i] == 2 && board[4][i] == 2)
				return 2;
		}
				
		
		for(int i = 0; i < 6; i++)
		{
			if(board[1][i] == 1 && board[2][i] == 1 && board[3][i] == 1 && board[4][i] == 1 && board[5][i] == 1)
				return 1;
			if(board[1][i] == 2 && board[2][i] == 2 && board[3][i] == 2 && board[4][i] == 2 && board[5][i] == 2)
				return 2;
		}
		
		if(board[0][1] == 1 && board[1][2] == 1 && board[2][3] == 1 && board[3][4] == 1 && board[4][5] == 1)
			return 1;
		if(board[0][1] == 2 && board[1][2] == 2 && board[2][3] == 2 && board[3][4] == 2 && board[4][5] == 2)
			return 2;
	
                
		if(board[1][0] == 1 && board[2][1] == 1 && board[3][2] == 1 && board[4][3] == 1 && board[5][4] == 1)
			return 1;
		if(board[1][0] == 2 && board[2][1] == 2 && board[3][2] == 2 && board[4][3] == 2 && board[5][4] == 2)
			return 2;
		
                
		if(board[0][4] == 1 && board[1][3] == 1 && board[2][2] == 1 && board[3][1] == 1 && board[4][0] == 1)
			return 1;
		if(board[0][4] == 2 && board[1][3] == 2 && board[2][2] == 2 && board[3][1] == 2 && board[4][0] == 2)
			return 2;
	
                
		if(board[1][5] == 1 && board[2][4] == 1 && board[3][3] == 1 && board[4][2] == 1 && board[5][1] == 1)
			return 1;
		if(board[1][5] == 2 && board[2][4] == 2 && board[3][3] == 2 && board[4][2] == 2 && board[5][1] == 2)
			return 2;
		
                
		if(board[0][0] == 1 && board[1][1] == 1 && board[2][2] == 1 && board[3][3] == 1 && board[4][4] == 1)
			return 1;
		if(board[0][0] == 2 && board[1][1] == 2 && board[2][2] == 2 && board[3][3] == 2 && board[4][4] == 2)
			return 2;
		
                
		if(board[1][1] == 1 && board[2][2] == 1 && board[3][3] == 1 && board[4][4] == 1 && board[5][5] == 1)
			return 1;
		if(board[1][1] == 2 && board[2][2] == 2 && board[3][3] == 2 && board[4][4] == 2 && board[5][5] == 2)
			return 2;
		
                
		if(board[0][5] == 1 && board[1][4] == 1 && board[2][3] == 1 && board[3][2] == 1 && board[4][1] == 1)
			return 1;
		if(board[0][5] == 2 && board[1][4] == 2 && board[2][3] == 2 && board[3][2] == 2 && board[4][1] == 2)
			return 2;
		
                
		if(board[1][4] == 1 && board[2][3] == 1 && board[3][2] == 1 && board[4][1] == 1 && board[5][0] == 1)
			return 1;
		if(board[1][4] == 2 && board[2][3] == 2 && board[3][2] == 2 && board[4][1] == 2 && board[5][0] == 2)
			return 2;
		
		
		//no winner 
		return 0;
	}
}
