
import java.util.Scanner;


public class bazi2 {

	static GameBoard board;
	static int currentPlayer;
	
        bazi2(){
         
            currentPlayer = 0;
        }
	
	private static void startGame()
	{		
		
		Scanner sc = new Scanner(System.in);
                
        String input = sc.nextLine();
              
		//while no current winner
		while(board.determineWinner() == 0)
		{
			
			if(currentPlayer == 1)
			{	
                            input = sc.nextLine();
				 
				 if(input != null)
				 {
					 
					 board.printBoard();
				 }
			}
	
        
        }
}
    
    public static void main(String []args){   
        
		board = new GameBoard();
		board.printBoard();
		
        startGame();
                }
    
}

