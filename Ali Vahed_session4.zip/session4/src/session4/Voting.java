/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session4;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Scanner;

/**
 *
 * @author Ali
 */
public class Voting {
    
    Boolean type;// 0 -----> tak ray      1 ------> chand ray
    String question;
    String gozine;
    HashMap<String,HashSet<String>> choices = new HashMap<String,HashSet<String>>();

    Scanner sc = new Scanner(System.in);

   public void createChoice(){
       ArrayList<String> votes = null;
       votes.add(gozine);
   } 
   
   // name of person who voted...
   public void vote(String name , String gozine){
         name = sc.nextLine();
         gozine = sc.nextLine();
   }
   
   void printResult(){
       System.out.printf("%s",choices);
        System.out.printf("%s",gozine);
   }
}
