/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session4;

import java.util.ArrayList;
import java.util.Scanner;
/**
 *
 * @author Ali
 */
public class VotingSystem {
    Scanner scan = new Scanner(System.in);
    ArrayList<String>votingList;
    
    public VotingSystem(){
    }
    
    public void creatvote(String s){
         s = scan.nextLine();
         votingList = new ArrayList<>();
    }
    
    public void printListOfVotings(String s){
        System.out.println(s);
    }
    
    public void printVoting(int num){
        num = scan.nextInt();
        System.out.println();
    }
    
    public void vote(int num,String name){
        num = scan.nextInt();
        name = scan.nextLine();        
    }
    
    public void printResult(int num){
        num = scan.nextInt();
        System.out.println();
    }
}
