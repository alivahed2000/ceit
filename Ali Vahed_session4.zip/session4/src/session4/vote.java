/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session4;

import java.util.Scanner;

/**
 *
 * @author Ali
 */

enum Person{
        family,name;
    }

public class vote {
    
    Person person;
    String date;
    
    Scanner sc = new Scanner(System.in);
    
    vote(Person person,String date){
        
        this.person = person;
        this.date = date;
    }
    
    public void getperson(Person person){
        Person.valueOf("name");
        Person.valueOf("family");
        
    }
    
    public void getDate(String date){
        date = sc.nextLine();
    }
    
    @Override
    public boolean equals(Object obj){
        
        if(this == obj){
        return true;
        }
        
        if(obj == null){
        return false;
        }
        
        return false;
    }
}
