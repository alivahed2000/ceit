/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package part1;

import java.awt.*;
import java.awt.event.ActionListener;
import javafx.event.ActionEvent;
import javax.swing.*;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;

/**
 *
 * @author Ali
 */
public class GUI {
    
   JFrame jf;
    
    public GUI(){
        init();
    } 
  public void init(){
        JFrame jf = new JFrame("Insomnia");
                 jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                 jf.setSize(1920,1080);  
		jf.setVisible(true); 
                
              JPanel jp = new JPanel();

                 JMenuBar menubar = new JMenuBar();
              jf.setJMenuBar(menubar);
              JMenu app = new JMenu(" Application ");
               menubar.add(app);
              JMenu edit = new JMenu(" Edit ");
               menubar.add(edit);
              JMenu view = new JMenu(" View ");
               menubar.add(view);
              JMenu window = new JMenu(" Window ");
              menubar.add(window);
              JMenu tools = new JMenu(" Tools ");
              menubar.add(tools);
              JMenu help = new JMenu(" Help ");
              menubar.add(help);  
              
              
              jp.setBackground(Color.gray);
              jf.add(jp);
            jf.show();
  }
        
}    
