/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package session3;
import java.util.ArrayList;
import java.lang.String;

/**
 *
 * @author Ali
 */
public class MusicOrganizer {
    
   private ArrayList<String> tracks;
   
   public void removeTrack(CharSequence nameLike) 
   { 
       for (int i = 0; tracks.size() > i; i++) 
       if(tracks.get(i).contains(nameLike)) 
           tracks.remove(i);
   }
}
