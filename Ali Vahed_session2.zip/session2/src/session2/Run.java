/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session2;

/**
 *
 * @author Ali
 */
public class Run {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
          
        Student std1 = new Student("Ehsan","Edalat", "9031066");
 Student std2 = new Student("Seyed", "Ahmadpanah", "9031806");
 Student std3 = new Student("Ahmad", "Asadi", "9031054");

 std1.print();
 std1.setGrade(15);
 std1.print();

 std2.print();
 std2.setGrade(11);
 std2.print();

 std3.print();
 std3.setFirstName("HamidReza");
std3.print();
    }

}
