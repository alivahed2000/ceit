/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session2;

/**
 *
 * @author Ali
 */
public class Student {
    
    // the student’s first name
 private String firstName;
 // the student’s last name
 private String lastName;
 // the student ID
 private String id;
 //the grade
 private int grades;
 
 //constructor
 public Student(String fName, String lname, String sID){
 firstName = fName;
 lastName = lname;
 id = sID;
 grades = 0;
 }
 
 public String getFirstName() {
 return firstName;
}
 
/**
* @param firstName set first name of a student
*/
 
public void setFirstName(String fName) {
 firstName = fName;
}

/**
* Print the student’s last name and ID number to the
output terminal.
*/

public void print() {
 System.out.println(lastName + ", student ID: "
 + id + ", grade: " + grades);
}

   public void setGrade(int grade){
     grades = grade;  
    } 
}
